﻿using System.Data;
using FluentMigrator;

namespace $rootnamespace$
{
	[Migration($migrationId$)]
    public class $safeitemname$ : Migration
    {
		public override void Up()
        {
            throw new System.NotImplementedException();
        }

        public override void Down()
        {
            throw new System.NotImplementedException();
        }        
    }
}